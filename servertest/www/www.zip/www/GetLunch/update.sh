sudo python2.7 "/home/pi/Desktop/_My Python Projects/Python2/Web Scraper/DownloadMySchoolDiningSA.py" | sudo tee -a /var/www/html/GetLunch/LunchMenu.html
